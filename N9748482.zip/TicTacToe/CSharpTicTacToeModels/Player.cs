﻿namespace QUT.CSharpTicTacToe
{
    public enum Player
    {
        Nought,
        Cross
    }
}
